#pragma once
#include <iostream>
#include <string>
#include <vector>
using namespace std;

template <typename T>
class LinkedList
{
public:
	struct Node;
	/************* BEHVAOIRS ***********/
	void PrintForward() const;		//print the linked list in foward order - done
	void PrintReverse() const;		//print the linked list in reverse orderv - done
	void PrintForwardRecursive(const Node* node) const;		
	void PrintReverseRecursive(const Node* node) const;		

	/************* ACCESSORS ***********/
	unsigned int NodeCount() const;												// done
	void FindAll(vector<Node*>& outData, const T& value) const;
	const Node* Find(const T& data) const;
	Node* Find(const T* data);
	const Node* GetNode(unsigned int index) const;
	Node* GetNode(unsigned int index);
	Node* Head();														//done
	const Node* Head() const;											//done
	Node* Tail();														//done
	const Node* Tail() const;											//done

	/************* INSERTION ***********/
	void AddHead(const T& data);										//done
	void AddTail(const T& data);										//done
	void AddNodesHead(const T* data, unsigned int count);
	void AddNodesTail(const T* data, unsigned int count);
	void InsertAfter(Node* node, const T& data);
	void InsertBefore(Node* node, const T& data);
	void InsertAt(const T& data, unsigned int index);

	/************* Removal ***********/
	bool RemoveHead();
	bool RemoveTail();
	unsigned int Remove(const T& data);
	bool RemoveAt(unsigned int index);
	void Clear();

	/************* Operators ***********/
	const T& operator[](unsigned int index) const;
	T& operator[](unsigned int index);
	bool operator==(const LinkedList<T>& rhs) const;
	LinkedList<T>& operator=(const LinkedList<T>& rhs);

	/************* Construction/Destruction ***********/
	LinkedList();												//done
	LinkedList(const LinkedList<T>& list);						//done
	~LinkedList();												//done

	struct Node {				//nested node
		T data;
		Node* next = nullptr;
		Node* prev = nullptr;

		friend class LinkedList;
	};

private:
	Node* head = nullptr;
	Node* tail = head;
	unsigned int qty;


	Node* NewNode(T data, Node* _next, Node* _prev);



};
/* ------------------------ END DECLARATIONS -----------------------------*/
template <typename T>
typename LinkedList<T>::Node* LinkedList<T>::NewNode(T data, Node* _next, Node* _prev) {			//create a new node
	Node* nodeptr = new Node;
	nodeptr->data = data;
	nodeptr->next = _next;
	nodeptr->prev = _prev;
	qty++;

	return nodeptr;
	delete nodeptr;
}

template <typename T>
LinkedList<T>::LinkedList() {
	LinkedList<T>::head = nullptr;
	LinkedList<T>::tail = nullptr;
	qty = 0;
}

template <typename T>
LinkedList<T>::LinkedList(const LinkedList<T>& list) {
	this->head = list.head;
	this->tail = list.tail;
	this->qty = list.qty;
}

template <typename T>
LinkedList<T>::~LinkedList() {
	Clear();
	//head = nullptr;			//reset the head ptr
	//tail = nullptr;			//reset the tail ptr
	qty = 0;				//reset the qty to 0
	 						//iterate through and delete the nodes
}

template <typename T>
void LinkedList<T>::Clear() {
	Node* nodereader = Head();

	while (nodereader != nullptr) {
		nodereader = nodereader->next;
		if (nodereader == nullptr) {
			qty = 0;
			return;
		}
		delete nodereader->prev;
	}
	delete nodereader;
	qty = 0;
}

template <typename T>
void LinkedList<T>::PrintForward() const {			//print the linked list in foward order
	
	const Node* nodereader = Head();

	while (nodereader != nullptr) {
		cout << nodereader->data << endl;
		nodereader = nodereader->next;
	}
	/*//Node n = *nodereader;
	//Node test = n;
	
	for (unsigned int i = 0; i < qty; i++) {
		T nodevalue = n.data;
		cout << nodevalue << endl;
		nodereader = n.next;
		if (nodereader != nullptr)
			n = *nodereader;
		else {
			//cout << test.prev;
			return;
		}

	}*/
}		

template <typename T>
void LinkedList<T>::PrintReverse() const {			//print the linked list in reverse order
	const Node* nodereader = Tail();
	while (nodereader != nullptr) {
		cout << nodereader->data << endl;
		nodereader = nodereader->prev;
	}
	return;
}	

template <typename T>
const T& LinkedList<T>::operator[](unsigned int index) const {
	if (index >= qty) {
		throw out_of_range("No such index");
	}
	Node* n = Head();
	for (int i = 0; i < index; i++) {
		n = n->next;
	}
	return *n->next;
}
template <typename T>
T& LinkedList<T>::operator[](unsigned int index) {
	if (index >= qty) {
		throw out_of_range("No such index");
	}
	Node* n = Head();
	for (int i = 0; i < index; i++) {
		n = n->next;
	}
	return *n->next;
}
template <typename T>
bool LinkedList<T>::operator==(const LinkedList<T>& rhs) const {
	Node* n = Head();
	Node* rhsptr = rhs;
	if (n->data == rhsptr->data) {
		n = n->next;
		rhsptr = rhsptr->next;
	}
	else if (n->data != rhsptr->data) {
		return false;
	}
	return true;
}
template <typename T>
LinkedList<T>& LinkedList<T>::operator=(const LinkedList<T>& rhs) {
	Node* n = LinkedList<T>::NewNode(rhs->data, rhs->next, rhs->prev);
	return *n;
}



template <typename T>
unsigned int LinkedList<T>::NodeCount() const {
	return qty;
}

template <typename T>
typename LinkedList<T>::Node* LinkedList<T>::Head() {
	return head;		//return a pointer to the head node
}

template <typename T>
const typename LinkedList<T>::Node* LinkedList<T>::Head() const {
	return head;		//return a pointer to the head node thats not changeable
}

template <typename T>
typename LinkedList<T>::Node* LinkedList<T>::Tail() {
	if (head->next == nullptr) {
		return head;
	}
	else {
		Node* tailptr = Head();
		while (tailptr->next != nullptr) {
			tailptr = tailptr->next;
		}
		return tailptr;
	}
}

template <typename T>
const typename LinkedList<T>::Node* LinkedList<T>::Tail() const {
	if (head == nullptr) {
		return nullptr;
	}

	else if (head->next == nullptr) {
		return head;
	}
	else {
		const Node* tailptr = Head();
		while (tailptr->next != nullptr) {
			tailptr = tailptr->next;
		}
		return tailptr;
	}
}

template <typename T>
void LinkedList<T>::AddHead(const T& data) {
		Node* newnode = LinkedList<T>::NewNode(data, nullptr, nullptr);
		if (qty == 1) {
			head = newnode;
			tail = newnode;
		}
		else {
			head->prev = newnode;
			newnode->next = head;
			head = newnode;
		}
		return;
}

template <typename T>
void LinkedList <T>::AddTail(const T& data) {
	Node* newnode = LinkedList<T>::NewNode(data, nullptr, nullptr);

	if (qty == 1) {
		head = newnode;
		tail = newnode;
	}
	else {
		tail->next = newnode;
		newnode->prev = tail;
		tail = newnode;

	}
	return;
}

template <typename T>
void LinkedList<T>::AddNodesHead(const T* data, unsigned int count) {

	for (unsigned int i = count -1; i >= 0; i--) {
		AddHead(*data);		//make new node with the data at 'i' in the array;
		data--;		//move the pointer back one address
	}
	return;
}


template <typename T>
void LinkedList<T>::AddNodesTail(const T* data, unsigned int count) {
	for (unsigned int i = 0; i < count; i++) {
		LinkedList<T>::AddTail(*data);
		data++;
	}
}